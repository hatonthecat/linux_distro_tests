#include "holecp.h"

/* Determine program name, e.g. /usr/bin/holecp is program holecp */

void getprogname (char const *av0)
{
    register char const
	*cp;

    if ( (cp = strrchr (av0, '/')) && *(cp + 1) )
	progname = cp + 1;
    else
	progname = av0;
}
