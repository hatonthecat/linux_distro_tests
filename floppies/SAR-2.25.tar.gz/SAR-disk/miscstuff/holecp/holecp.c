#include "holecp.h"

char const
    *progname;
FLAGS
    flags;

int main (int argc, char **argv)
{
    register int
	i,
	exitstatus = 0;
    
    getprogname (argv [0]);

    parseargs (&argc, &argv);
    
    if (argc < 3)
	usage ();

    for (i = 1; i < argc - 1; i++)
	exitstatus += copyfiles (argv [i], argv [argc - 1]);

    return (exitstatus);
}
