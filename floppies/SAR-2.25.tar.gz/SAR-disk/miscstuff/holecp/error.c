#include "holecp.h"

/* print error msg and die */

void error (char const *fmt, ...)
{
    va_list
	args;
    
    fprintf (stderr, "%s: ", progname);
    va_start (args, fmt);
    vfprintf (stderr, fmt, args);
    fputc ('\n', stderr);

    exit (1);
}
