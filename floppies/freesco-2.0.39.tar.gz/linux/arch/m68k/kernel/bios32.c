/*
 * bios 32 replacement
 */
unsigned long bios32_init(unsigned long memory_start, unsigned long memory_end)
{
	return memory_start;
}
