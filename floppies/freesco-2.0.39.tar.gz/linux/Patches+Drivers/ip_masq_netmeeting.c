/*

IP_MASQ_NETMEETING Netmeeting masquerading module
Author:	Alex Nicolaou, LiquiMedia Inc., http://www.liquimedia.com/
        http://www.cgl.uwaterloo.ca/~anicolao/ to contact the author
	Copyright (C) 1999 LiquiMedia Inc. Distributed under GPL.

This module deals with allowing Netmeeting -> Netmeeting calls through
a firewall with IP Masquerade turned on. I have tested it with Netmeeting 3
calling Netmeeting 3 and with SunForum 3 calling Netmeeting 3. 

The reason this is necessary has to do with the fact that the protocols
netmeeting uses embed the destination IP address and port number inside
application level data. The module works by scanning through the packet
data and fiddling the insides in order to ensure that the packets get
properly redirected.

Here's what happens:

1. A machine within the firewall, which we'll call the "caller",  
initiates a netmeeting call to a machine outside the firewall, 
which we'll call the "callee". This is done by opening a TCP 
connection on port 1720.

2. A few packets later, the caller sends the callee a packet on the
existing 1720 connection which includes the caller's IP address. I
rewrite this to the firewall's address, although this may not be
necessary, strictly speaking. It is only after this packet is sent
that additional channels of communication are opened.

3. The callee sends to the caller a request to open a new tcp channel, 
using the existing 1720 channel. We'll refer to this new connection as
the secondary TCP channel. The request to open the channel can be 
identified because the application level data includes the callee's 
IP address and the desired port for the connection.

4. The caller opens the secondary TCP channel.

5. The caller sends to the callee open channel requests that encode
the caller's IP and a port number; these open channel requests 
correspond to channels for UDP data carrying audio and video packets.
The module adds entries to the masq tables for these channels and 
rewrites the data going to the callee to point at the firewall's 
address and the masq'ed port number.

6. Audio and video data arrives at the firewall on the masq'ed port
and the packets are redirected to the appropriate caller.

7. The module limits the number of structures it is willing to allocate
so that it won't use up all of the kernel memory in the event of many
converstaions through the firewall. The number of monitored ports is
limited by monitor_limit, which can be set at insmod time with a
command like "insmod ip_masq_netmeeting.o monitor_limit=40". The default
limit is 16, which will allow several simultaneous netmeeting connections. 

For incoming calls, you need to manually forward several ports by
hand to a single machine inside your firewall. On 2.0.X kernels, 
the commands you need to enter are something like:

ipautofw -F
ipautofw -A -r tcp 1503 1503 -h 10.0.0.1
ipautofw -A -r tcp 1720 1720 -h 10.0.0.1
ipautofw -A -r tcp 1731 1731 -h 10.0.0.1

Note that the first one flushes all forwarding rules, so if you are
using forwarding for something else you'll probably not want to do 
that part. After that, incoming calls should ring on the given IP
(10.0.0.1 in this example) and you can answer and talk as usual. Even 
in the incoming call case, the machine inside your firewall is still
referred to as the "caller". 

License:

	This program is free software; you can redistribute it and/or
 	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version
 	2 of the License, or (at your option) any later version.
*/

#include <linux/module.h>
#include <asm/system.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/skbuff.h>
#include <linux/in.h>
#include <linux/ip.h>
#include <net/protocol.h>
#include <net/udp.h>
#include <net/tcp.h>
#include <net/ip_masq.h>

/* limit the number of forwarding entries to this, settable as a parameter */
#define MONITOR_LIMIT_DEFAULT 16
static int monitor_limit = MONITOR_LIMIT_DEFAULT;

/* get lots of log messages in /var/log/kern.log */
/* comment out to compile out all logging for absolute fastest execution */
#define DEBUG_CONFIG_IP_MASQ_NETMEETING 1

#ifndef DEBUG_CONFIG_IP_MASQ_NETMEETING
#define DEBUG_CONFIG_IP_MASQ_NETMEETING 0
#endif

/* debug levels; higher numbers means more detail */
#define DEBUG_VERBOSE	4	/* log all that goes on */
#define DEBUG_INFO	3	/* info messages - very few per call */
#define DEBUG_WARNING	2	/* warning messages */
#define DEBUG_ERROR	1	/* error messages */
#define DEBUG_OFF	0	/* set debug to this to stop all debug */
#define DEBUG_ALWAYS	-1	/* use this in PRINTK calls to always log msg */

#define PRINTK(level,fmt,arg...) \
	if (level <= debug) {printk(fmt,##arg);}

static int debug = DEBUG_INFO;	/* log basic activity and warn/errors */
				/* some LINUX ver's let you set this on module load command line */

#if   (LINUX_VERSION_CODE >= 0x020400)
#error this module has never been tested/compiled with Linux 2.4

#elif (LINUX_VERSION_CODE >= 0x020300)
#error this module has never been tested/compiled with Linux 2.3

#elif (LINUX_VERSION_CODE >= 0x020200)

MODULE_PARM(monitor_limit, "i");
/* load module with "debug=x" where x matches DEBUG_ define above */
MODULE_PARM(debug, "i");


#define GET_IP_HEADER(skb) (skb->nh.iph)

#define IP_MASQ_NEW_UDP(saddr, port, daddr) \
	ip_masq_new(IPPROTO_UDP, ms->maddr, 0, saddr, port, daddr, \
		    0, IP_MASQ_F_NO_DPORT)

#define IP_MASQ_GET_UDP(saddr, port, daddr) \
	ip_masq_out_get(IPPROTO_UDP, saddr, port, daddr, 0)

#define IP_MASQ_NEW_TCP(saddr, port, daddr) \
	ip_masq_new(IPPROTO_TCP, ms->maddr, 0, saddr, port, daddr, \
		    0, IP_MASQ_F_NO_DPORT)

#define IP_MASQ_GET_TCP(saddr, port, daddr) \
	ip_masq_out_get(IPPROTO_TCP, saddr, port, daddr, 0)

#define IP_MASQ_KEEPALIVE(n_ms) \
	{/* no-op in v2.2, done by GET_UDP */}

#define DEV_T __u32

#elif (LINUX_VERSION_CODE >= 0x020100)
#error this module has never been tested/compiled with Linux 2.1

#elif (LINUX_VERSION_CODE >= 0x020000)
#define GET_IP_HEADER(skb) (skb->h.iph)

#define IP_MASQ_NEW_UDP(saddr, port, daddr) \
	ip_masq_new(dev, IPPROTO_UDP, saddr, port, daddr, \
		    0, IP_MASQ_F_NO_DPORT)

#define IP_MASQ_GET_UDP(saddr, port, daddr) \
	ip_masq_out_get_2(IPPROTO_UDP, saddr, port, daddr, 0)

#define IP_MASQ_NEW_TCP(saddr, port, daddr) \
	ip_masq_new(dev, IPPROTO_TCP, saddr, port, daddr, \
		    0, IP_MASQ_F_NO_DPORT)

#define IP_MASQ_GET_TCP(saddr, port, daddr) \
	ip_masq_out_get_2(IPPROTO_TCP, saddr, port, daddr, 0)

#define IP_MASQ_KEEPALIVE(n_ms) \
	ip_masq_set_expire(n_ms,0)

#define EXPORT_NO_SYMBOLS \
        register_symtab(0)

#define DEV_T struct device*

#else
#error Your version of Linux is too old. How about upgrading?
#endif

/* singly linked list of ports currently being watched */
typedef struct _port_list_entry {
	int port;
	struct _port_list_entry *next;
	struct ip_masq_app masq;
} PortListEntry;

static PortListEntry *ports = 0;
static PortListEntry *unloadqueue = 0;

/*
   adds a new portnumber to the list of ports being monitored by this code 
*/
static int ip_masq_netmeeting_monitor_port(int portno);
//static int ip_masq_netmeeting_queue_port(int portno);
static int ip_masq_netmeeting_queue_port(struct ip_masq_app *mapp);
static int ip_masq_netmeeting_unregister_list(PortListEntry **cptr);
PortListEntry *ip_masq_netmeeting_masq2PortListEntry(struct ip_masq_app *mapp);

static int
masq_netmeeting_init_1 (struct ip_masq_app *mapp, struct ip_masq *ms)
{
        MOD_INC_USE_COUNT;
        return 0;
}

static int
masq_netmeeting_done_1 (struct ip_masq_app *mapp, struct ip_masq *ms)
{
	PortListEntry *ple = NULL;
	ple = ip_masq_netmeeting_masq2PortListEntry(mapp);

	//if (ntohs(ms->sport) != 1720) {
	if ((ple != NULL) && (ple->port != 1720)) {
#ifdef DEBUG_CONFIG_IP_MASQ_NETMEETING
		//PRINTK(DEBUG_VERBOSE, KERN_INFO "putting %d on unload queue (%x)\n", ntohs(ms->sport), (int)mapp);
		PRINTK(DEBUG_VERBOSE, KERN_INFO "putting %d on unload queue (%x)\n", ple->port, (int)mapp);
#endif
		//ip_masq_netmeeting_queue_port(ntohs(ms->sport));
		ip_masq_netmeeting_queue_port(mapp);
	}

	if (ms->app_data != NULL) {
	    kfree(ms->app_data);	/* Conversation object too */
	}
	ms->app_data = NULL;

        MOD_DEC_USE_COUNT;
        return 0;
}

#define ARRAYSIZE(X) (sizeof(X)/sizeof(X[0]))

/* 
   return the first, second, third and fourth byte of an IP address,
   considering FIRST to be the first number in standard X.X.X.X notation,
   and assuming the address is in network byte order
*/
#define FIRST(x) ((x)&0x00ff)
#define SECOND(x) ((x>>8)&0x00ff)
#define THIRD(x) ((x>>16)&0x00ff)
#define FOURTH(x) (x>>24)

typedef enum _state { 
	UNUSED, 
	OPENED, /* conversation has started but channel opens aren't expected */
	NEXT_CHANNEL_MATTERS, /* next channel open needs to be monitored */
	NEXT_CHANNEL_MATTERS_INCOMING, /* next channel open needs to be monitored due to incoming call */
	DONE, /* not yet used */
	SECONDARY_TCP_CONNECTION /* this state needs constant monitoring */
} State;

typedef struct _conversation {
	State state;
} Conversation;

/*
   new_connection is used to allocate the connection structure, which is 
   placed in the app_data portion of the masq record for each connection.
*/
Conversation *new_connection( void )
{
	Conversation *ret = kmalloc(sizeof(Conversation), GFP_ATOMIC);
	if (ret == NULL) 
		return ret;
	ret->state = OPENED;

	return ret;
}

/*
   Both incoming and outgoing packets are processed by this filter, which
   does all necessary rewrites of addresses and adds entries to the masq
   table. This function is basically the entire module
*/
int
masq_netmeeting_io(struct ip_masq_app *mapp, struct ip_masq *ms, struct sk_buff **skb_p, DEV_T dev)
{
	struct sk_buff *skb = *skb_p;
	struct iphdr *iph = GET_IP_HEADER(skb);
	struct tcphdr *th = (struct tcphdr *)&(((char *)iph)[iph->ihl*4]);
	unsigned char *data = (char *)&th[1];
	unsigned char *data_start = (char *)&th[1];
	unsigned char *data_limit = skb->h.raw + skb->len;
	Conversation *conn = (Conversation*)ms->app_data;

	/* avoid overrun in loop below */
	data_limit -= 3;

	ip_masq_netmeeting_unregister_list(&unloadqueue);

#if 1
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
PRINTK(DEBUG_VERBOSE, KERN_INFO "io (%x) %d (%ld), %d.%d.%d.%d:%d -> %d.%d.%d.%d:%d -> %d.%d.%d.%d:%d\n", 
	(int)mapp,
	data_limit-data,
	skb->len,
	FIRST(ms->saddr),
	SECOND(ms->saddr),
	THIRD(ms->saddr),
	FOURTH(ms->saddr),
	ntohs(ms->sport),

	FIRST(ms->maddr),
	SECOND(ms->maddr),
	THIRD(ms->maddr),
	FOURTH(ms->maddr),
	ntohs(ms->mport),

	FIRST(ms->daddr),
	SECOND(ms->daddr),
	THIRD(ms->daddr),
	FOURTH(ms->daddr),
	ntohs(ms->dport));
#endif
#endif

	if (th->ack == 0) {
		if (ms->app_data == NULL) {
			ms->app_data = new_connection();
			PRINTK(DEBUG_VERBOSE, KERN_INFO "new conn (%x)\n", (int)mapp);
			conn = (Conversation*)ms->app_data;
		}
		if (ntohs(th->dest) != 1720) {
			conn->state = SECONDARY_TCP_CONNECTION;
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_VERBOSE, KERN_INFO "IP_MASQ_NETMEETING: monitoring secondary TCP connection on port %d --> %d (%x)\n", ntohs(th->source), ntohs(th->dest),(int)mapp);
#endif
		}
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
		else {
			PRINTK(DEBUG_VERBOSE, KERN_INFO "primary netmeeting conn (%x)\n", (int)mapp);
			PRINTK(DEBUG_VERBOSE, KERN_INFO "   caller: %d.%d.%d.%d:%d\n", 
				FIRST(ms->saddr),
				SECOND(ms->saddr),
				THIRD(ms->saddr),
				FOURTH(ms->saddr),
				ntohs(ms->sport));
			PRINTK(DEBUG_VERBOSE, KERN_INFO "   firewall: %d.%d.%d.%d:%d\n", 
				FIRST(ms->maddr),
				SECOND(ms->maddr),
				THIRD(ms->maddr),
				FOURTH(ms->maddr),
				ntohs(ms->mport));
			PRINTK(DEBUG_VERBOSE, KERN_INFO "   callee: %d.%d.%d.%d:%d\n",
				FIRST(ms->daddr),
				SECOND(ms->daddr),
				THIRD(ms->daddr),
				FOURTH(ms->daddr),
				ntohs(ms->dport));
		}
#endif
	}
	if (th->fin == 1 && ntohs(ms->sport) != 1720) {
#ifdef DEBUG_CONFIG_IP_MASQ_NETMEETING
		PRINTK(DEBUG_VERBOSE, KERN_INFO "IP_MASQ_NETMEETING: fin -- should shortly unload support on %d\n", ntohs(ms->sport));
#endif
	}

	if (!conn) {
		PRINTK(DEBUG_ERROR, KERN_INFO "IP_MASQ_NETMEETING: ERROR - no app_data after connection is open? (%x) ack=%d, src=%d, dest=%d\n",(int)mapp,th->ack, ntohs(th->source), ntohs(th->dest));
		return 0;
	}

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
	PRINTK(DEBUG_VERBOSE, KERN_INFO "Analyzing %d --> %d packet (%x)\n", ntohs(th->source), ntohs(th->dest), (int)mapp);
#endif
	while (data < data_limit) {
		/*
		 * Start monitoring only if this is an outgoing call (to outside).
		 * Monitoring an incoming (from outside) call results in this monitor never
		 * begin cleaned up because no connection is started.
		 */
		if (conn->state == NEXT_CHANNEL_MATTERS &&
		    !memcmp(data, &(ms->daddr), 4)) {

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			int ip = *((__u32*)data);
			PRINTK(DEBUG_INFO, KERN_INFO "IP_MASQ_NETMEETING: Calling IP Address: %d.%d.%d.%d from %d.%d.%d.%d (%x)\n", 
				FIRST(ip),
				SECOND(ip),
				THIRD(ip),
				FOURTH(ip),
				FIRST(ms->saddr),
				SECOND(ms->saddr),
				THIRD(ms->saddr),
				FOURTH(ms->saddr),
				data-data_start);
#endif

			{
			int ret;
			int port = (((int)(*(data+4)))<<8) | (*(data+5)); 
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_VERBOSE, KERN_INFO "channel from in-->out opened on %d\n", port);
#endif
			ret = ip_masq_netmeeting_monitor_port(port);
			/* conn->state = DONE; */

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_VERBOSE, KERN_INFO "monitor ret1: %d\n", ret);
#endif
			}
		}

		if (conn->state == OPENED && !memcmp(data, &(ms->daddr), 4)) {
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_VERBOSE, KERN_INFO "next channel open matters. (%x)\n",
				data-data_start);
#endif
			conn->state = NEXT_CHANNEL_MATTERS;
		}
		else if (conn->state == OPENED && 
                   !memcmp(data, &(ms->maddr), 4)) {
			PRINTK(DEBUG_INFO, KERN_INFO "IP_MASQ_NETMEETING: %d.%d.%d.%d is calling into %d.%d.%d.%d; next ch open matters; rewrite. (%x)\n", 
				FIRST(ms->daddr),
				SECOND(ms->daddr),
				THIRD(ms->daddr),
				FOURTH(ms->daddr),
				FIRST(ms->saddr),
				SECOND(ms->saddr),
				THIRD(ms->saddr),
				FOURTH(ms->saddr),
				data-data_start);
			conn->state = NEXT_CHANNEL_MATTERS_INCOMING;
			memcpy(data, &(ms->saddr), 4);
			data++;
			continue;
		}

		if (!memcmp(data, &(ms->saddr), 4)) {
			/* our IP address */
			int port;
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			int ip = *((__u32*)data);
			PRINTK(DEBUG_VERBOSE, KERN_INFO "Caller's IP Address: (%x) %d.%d.%d.%d\n", 
				data-data_start,
				FIRST(ip),
				SECOND(ip),
				THIRD(ip),
				FOURTH(ip));
#endif

			PRINTK(DEBUG_VERBOSE, KERN_INFO "rewriting IP\n");
			memcpy(data, &(ms->maddr), 4);
			data += 4;

			port = (((int)(*data))<<8) | ((int)(*(data+1)));
			if (conn->state == SECONDARY_TCP_CONNECTION && 
                           port != 1503) {
				struct ip_masq *n_ms = IP_MASQ_GET_UDP(
								ms->saddr,
								htons(port),
								ms->daddr);
				if (n_ms) {
					/* reset expiry to keep entry alive */
					IP_MASQ_KEEPALIVE(n_ms);
				}
				else {
					/* no entry yet; make one */
					n_ms = IP_MASQ_NEW_UDP(ms->saddr, 
							       htons(port),
							       ms->daddr);
				}

				/* n_ms->mport contains the port on which data
				   must arrive to be correctly forwarded */
				memcpy(data, &(n_ms->mport), 2);

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
				{
				int p = (((int)(*data))<<8)|((int)(*(data+1)));
				PRINTK(DEBUG_VERBOSE, KERN_INFO "REWROTE port %d --> %d (%x)\n", 
							port, p, data-data_start);
				}
				PRINTK(DEBUG_VERBOSE, KERN_INFO "forwarding UDP data\n");
#endif
			}
			// Open forwarding/monitor if we're being solicited.
			else if ((port != 1503) && (ntohs(th->source) == 1720)) {
				int ret;

				struct ip_masq *n_ms = IP_MASQ_GET_TCP(
								ms->saddr,
								htons(port),
								ms->daddr);

#if 1
				ret = ip_masq_netmeeting_monitor_port(port);
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
				PRINTK(DEBUG_VERBOSE, KERN_INFO "monitoring ret2: %d\n", ret);
#endif
#endif

				if (n_ms) {
					/* reset expiry to keep entry alive */
					IP_MASQ_KEEPALIVE(n_ms);
				}
				else {
					/* no entry yet; make one */
					n_ms = IP_MASQ_NEW_TCP(ms->saddr, 
							       htons(port),
							       ms->daddr);
				}

				/* n_ms->mport contains the port on which data
				   must arrive to be correctly forwarded */
				memcpy(data, &(n_ms->mport), 2);

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
				{
				int p = (((int)(*data))<<8)|((int)(*(data+1)));
				PRINTK(DEBUG_VERBOSE, KERN_INFO "REWROTE port %d --> %d (%x)\n", 
							port, p, data-data_start);
				}
				PRINTK(DEBUG_VERBOSE, KERN_INFO "forwarding TCP data\n");
#endif

#if 0
				ret = ip_masq_netmeeting_monitor_port(ntohs(n_ms->mport));
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
				PRINTK(DEBUG_VERBOSE, KERN_INFO "monitoring ret3: %d\n", ret);
#endif
#endif

			}
		}
		data++;
	}

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
	PRINTK(DEBUG_VERBOSE, KERN_INFO "Done processing packet\n");
#endif

	return 0;
}

struct ip_masq_app ip_masq_netmeeting = {
        NULL,			/* next */
        "netmeeting",
        0,                      /* type */
        0,                      /* n_attach */
        masq_netmeeting_init_1,	/* ip_masq_init_1 */
        masq_netmeeting_done_1,	/* ip_masq_done_1 */
        masq_netmeeting_io,	/* pkt_out */
        masq_netmeeting_io    	/* pkt_in */
};


/*
 * 	ip_masq_netmeeting initialization
 */


static int ip_masq_netmeeting_monitor_port(int portno)
{
	int ret = 0;
	PortListEntry *newmasq;

	int limit_check = monitor_limit;
	PortListEntry *counter = ports;
	while (counter && (counter = counter->next)) {
		limit_check--;
	}
	if (limit_check <= 0) {
		PRINTK(DEBUG_ERROR, KERN_INFO "IP_MASQ_NETMEETING: port limit exceeded\n");
		return -ENOMEM;
	}

	newmasq = kmalloc(sizeof(*newmasq), GFP_ATOMIC);
	if (newmasq == NULL) {
		PRINTK(DEBUG_ERROR, KERN_INFO "IP_MASQ_NETMEETING: ERROR out of RAM!\n");
		return -ENOMEM;
	}

	newmasq->port = portno;
	newmasq->next = ports;

	memcpy(&(newmasq->masq), &ip_masq_netmeeting, sizeof(newmasq->masq));
	if ((ret = register_ip_masq_app(&(newmasq->masq), IPPROTO_TCP, portno))) {
		kfree(newmasq);
		return ret;
	}

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
	PRINTK(DEBUG_VERBOSE, KERN_INFO "IP_MASQ_NETMEETING: monitoring port %d (%x)\n", portno,(int)&(newmasq->masq));
#endif
	ports = newmasq;
	return 0;
}

//static int ip_masq_netmeeting_queue_port(int portno)
static int ip_masq_netmeeting_queue_port(struct ip_masq_app *mapp)
{
	int ret = 0;
	PortListEntry *predecessor;
	PortListEntry *removeme;

	predecessor = 0;
	removeme = ports;
	//while (removeme != 0 && removeme->port != portno) {
	while (removeme != 0 && &(removeme->masq) != mapp) {
		predecessor = removeme;
		removeme = removeme->next;
	}
	if (removeme == 0) {
		/* no matching port found? bail out */
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
		//PRINTK(DEBUG_WARNING, KERN_INFO "IP_MASQ_NETMEETING: port %d not being monitored?\n", portno);
		PRINTK(DEBUG_WARNING, KERN_INFO "IP_MASQ_NETMEETING: mapp %x not being monitored?\n", (int)mapp);
#endif
		return -1;
	}
	if (predecessor == 0) {
		if (removeme != ports) {
			/* impossible! */
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_WARNING, KERN_INFO "IP_MASQ_NETMEETING: impossible?!\n");
#endif
			return -1;
		}
		ports = ports->next;
	}
	else {
		if (removeme != predecessor->next) {
			/* impossible! */
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_WARNING, KERN_INFO "IP_MASQ_NETMEETING: impossible?!\n");
#endif
			return -1;
		}
		predecessor->next = removeme->next;
	}

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
	PRINTK(DEBUG_VERBOSE, KERN_INFO "IP_MASQ_NETMEETING: queued remove on %d\n", removeme->port);
#endif
	removeme->next = unloadqueue;
	unloadqueue = removeme;

	return ret;
}

PortListEntry *ip_masq_netmeeting_masq2PortListEntry(struct ip_masq_app *mapp)
{
    PortListEntry ple, *pple;
    int offset = ((char *)&(ple.masq)) - (char *)&ple;	// offset from start to ip_masq
    pple = (PortListEntry *)(((char *)mapp) - offset);
    return pple;
}

int ip_masq_netmeeting_init(void)
{
	int i, ret;
	int init_ports[] = { 1720 };

#if DEBUG_CONFIG_IP_MASQ_NETMEETING
	if (monitor_limit != MONITOR_LIMIT_DEFAULT) {
		PRINTK(DEBUG_ALWAYS, KERN_INFO "IP_MASQ_NETMEETING: monitor_limit=%d\n", 
			monitor_limit);
	}
#endif
	for (i=0; i < ARRAYSIZE(init_ports); i++) {
		if (init_ports[i]) {
			ret = ip_masq_netmeeting_monitor_port(init_ports[i]);
			if (ret) return ret;
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_ALWAYS, KERN_INFO "IP_MASQ_NETMEETING: monitoring port %d\n", init_ports[i]);
#endif
		} 
	}
	return 0;
}

/*
 * 	ip_masq_netmeeting fin.
 */

static int ip_masq_netmeeting_unregister_list(PortListEntry **cptr)
{
	int tmp, ret;
	PortListEntry *freeme;
	PortListEntry *cur;

	if (!cptr) return -1;
	cur = (*cptr);
	(*cptr) = 0;

	ret = 0;
	while (cur != 0) {
		if ((tmp = unregister_ip_masq_app(&(cur->masq)))) {
			ret = tmp;
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_ERROR, KERN_INFO "IP_MASQ_NETMEETING: unloading support on port %d failed, ret=%d\n", cur->port, ret);
#endif
		} 
		else {
#if DEBUG_CONFIG_IP_MASQ_NETMEETING
			PRINTK(DEBUG_INFO, KERN_INFO "IP_MASQ_NETMEETING: unloading support on port %d\n", cur->port);
#endif
		}

		freeme = cur;
		cur = cur->next;
		kfree(freeme);
		freeme = 0;
	}
	return ret;
}

int ip_masq_netmeeting_done(void)
{
	return ip_masq_netmeeting_unregister_list(&ports);
	ports = 0;
}

#ifdef MODULE

int init_module(void)
{
        if (ip_masq_netmeeting_init() != 0)
                return -EIO;
	EXPORT_NO_SYMBOLS;
        return 0;
}

void cleanup_module(void)
{
        if (ip_masq_netmeeting_done() != 0) {
                PRINTK(DEBUG_WARNING, KERN_INFO "IP_MASQ_NETMEETING: can't remove module");
	}
}

#endif /* MODULE */


