#if defined(LCF_READONLY) && defined(LCF_REWRITE_TABLE)
#error "Incompatible options: READONLY and REWRITE_TABLE"
#endif
