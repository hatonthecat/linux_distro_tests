How to create your own QNX Demodisk   (Windows 95/NT/3.1 version)

After extracting the files from the QNXDEMO.ZIP file, the following files
should be present:

README.TXT   -- Intructions for making a QNX demodisk (this file).
INSTALL.BAT  -- A batch file to make the demodisk.
MAKEDISK.EXE -- A program used to write the QNX demodisk data to floppy disk.
QNXDEMO.DAT  -- The data to be written to the floppy disk.

Insert a 3.5", 1.44 Mbyte floppy disk into drive A of your computer. Switch
to the target directory, then run the command "INSTALL" from the MS-DOS
prompt, or run the INSTALL.BAT file by double-clicking on the document icon
in the Windows Explorer or File Manager.  This batch file will write the
QNX demodisk data to the floppy disk.  Once this process is complete, leave
the floppy disk in drive A and reset your computer.  The demodisk will do
the rest.

If your computer does not have a 3.5" floppy drive configured as drive A,
you will need to reconfigure your hardware or BIOS to allow it to boot from
the 3.5" drive.
